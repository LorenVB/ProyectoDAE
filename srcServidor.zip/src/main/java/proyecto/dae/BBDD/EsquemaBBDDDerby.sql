/************************* LIBROS *************************/

insert into Libro (isbn, autor, en_revision,fecha_publicacion, fecha_revision_asignada,notas,pendiente,publicado, revisado,tematica, titulo) values ( '1000','yo',false,null,null,null,false, true,true,'terror','harry1');
insert into Libro (isbn, autor, en_revision,fecha_publicacion, fecha_revision_asignada,notas,pendiente,publicado, revisado,tematica, titulo) values ( '1001','yo',false,null,null,null,false, true,true,'terror','harry2');
insert into Libro (isbn, autor, en_revision,fecha_publicacion, fecha_revision_asignada,notas,pendiente,publicado, revisado,tematica, titulo) values ( '1002','yo',false,null,null,null,true, false,false,'accion','django');
insert into Libro (isbn, autor, en_revision,fecha_publicacion, fecha_revision_asignada,notas,pendiente,publicado,revisado,tematica, titulo) values ( '1003','yo',false,null,null,null,true, false,false,'accion','harry3');
insert into Libro (isbn, autor, en_revision,fecha_publicacion, fecha_revision_asignada,notas,pendiente,publicado,revisado,tematica, titulo) values ( '1004','yo',false,null,null,null,true,false,false,'terror','perdida');

