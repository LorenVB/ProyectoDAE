/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.dae.servidor.RestController;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import static org.springframework.web.bind.annotation.RequestMethod.PUT;
import org.springframework.web.bind.annotation.RestController;
import proyecto.dae.servidor.beans.Sistema;
import proyecto.dae.servidor.clases.EstadoRevisionLibro;
import proyecto.dae.servidor.clases.Usuario;
import proyecto.dae.servidor.daos.UsuarioDAO;
import proyecto.dae.servidor.excepciones.NotaNoValida;
import proyecto.dae.servidor.excepciones.ParametrosIncorrectos;
import proyecto.dae.servidor.excepciones.UsuarioIncorrecto;
import proyecto.dae.servidor.excepciones.libroDatosErroneos;
import proyecto.dae.servidor.seguridad.SeguridadSistema;
import proyecto.dae.servidor.servicios.dto.LibroDTO;
import proyecto.dae.servidor.servicios.dto.UsuarioDTO;

/**
 *
 * @author Loren
 */

@RestController
@RequestMapping("/usuarios")
public class UsuariosRestController {
    @Autowired
    Sistema sistema;
    
    @Autowired
    UsuarioDAO usuarios;
    
    @Autowired
    SeguridadSistema seguridad;
    
    @RequestMapping(value="/registro",method=POST, produces="application/json")
    public void registrarUsuario(@RequestBody UsuarioDTO usuario) throws UsuarioIncorrecto{
        if(usuario==null){
           throw new UsuarioIncorrecto();
        }
        
        sistema.registrarUsuario(usuario.getNombre(),usuario.getEdad(),usuario.getEmail(),usuario.getPassword(),usuario.getRol());
    }
    
@RequestMapping(value="/login", method = GET, produces="application/json")
public UsuarioDTO logIn(@PathVariable String username) {		
			
            UsuarioDTO user = sistema.devuelveUsuario(username);
            return user;
}


    @RequestMapping(value = "/autor/{email}/libro/{ISBN}", method = POST, produces = "application/json")
    public void subirLibro(@RequestBody LibroDTO libro, @PathVariable String email,
                           @PathVariable String ISBN) throws libroDatosErroneos {

        if (email.equals("") || email == null || ISBN.equals("") || ISBN==null) {
            throw new ParametrosIncorrectos();
        }
        Usuario u = usuarios.buscarEmail(email);

        if (u == null) {
            throw new UsuarioIncorrecto();
        }

        sistema.subirLibro(libro, u);

    }

    @RequestMapping(value = "/editor/{email}/librosPendientes", method = GET, produces = "application/json")
    public List<LibroDTO> obtenerLibrosPendientes(@PathVariable String email) {
        if (email.equals("") || email == null) {
            throw new ParametrosIncorrectos();
        }
        Usuario u = usuarios.buscarEmail(email);

        if (u == null) {
            throw new UsuarioIncorrecto();
        }
        List<LibroDTO> librosPendientes = sistema.obtenerLibrosPendientesRevision(u);
        return librosPendientes;
    }

    @RequestMapping(value = "/editor/{email}/libro/{ISBN}/aceptado", method = GET, produces = "application/json")
    public void aceptarLibro(@PathVariable String email, @PathVariable String ISBN) {
        if (email.equals("") || email == null || ISBN.equals("") || ISBN==null) {
            throw new ParametrosIncorrectos();
        }
        Usuario u = usuarios.buscarEmail(email);

        if (u == null) {
            throw new UsuarioIncorrecto();
        }
        sistema.aceptarLibro(ISBN);

    }

    @RequestMapping(value = "/editor/{email}/libro/{ISBN}/rechazado", method = GET, produces = "application/json")
    public void rechazarLibro(@PathVariable String email, @PathVariable String ISBN) {
        if (email.equals("") || email == null || ISBN.equals("") || ISBN==null) {
            throw new ParametrosIncorrectos();
        }
        Usuario u = usuarios.buscarEmail(email);

        if (u == null) {
            throw new UsuarioIncorrecto();
        }
        sistema.rechazarLibro(ISBN);

    }


    @RequestMapping(value = "/revisor/{email}/libros?revision=true", method = GET, produces = "application/json")
    public List<LibroDTO> verListaPendientesRevisar(@PathVariable String email) {
        if (email.equals("") || email == null) {
            throw new ParametrosIncorrectos();
        }
        
        Usuario u = usuarios.buscarEmail(email);

        if (u == null) {
            throw new UsuarioIncorrecto();
        }
        
        List<LibroDTO> libPendRevisar = sistema.verListaPendientesRevisar(email);
        return libPendRevisar;
    }
    
 
    @RequestMapping(value = "/revisor/{email}/libro/{ISBN}/nota/{nota}", method = POST, produces = "application/json")
    public void asignarNota(@PathVariable String email, @PathVariable String ISBN,@PathVariable int nota) throws libroDatosErroneos {

        if(email.equals("") || email == null || ISBN.equals("") || ISBN==null) {
            throw new ParametrosIncorrectos();
        }
        
        Usuario u = usuarios.buscarEmail(email);

        if (u == null) {
            throw new UsuarioIncorrecto();
        }
        
        if(nota < 0 || nota > 5){
            throw new NotaNoValida();
        }

        sistema.asignarNota(nota, email);
    }
    
    
    
    @RequestMapping(value = "/devolverUsuario/{email}/", method = GET, produces = "application/json")
    public Usuario devuelveUsuario(@PathVariable String email) {
        if (email.equals("") || email == null) {
            throw new ParametrosIncorrectos();
        }
        Usuario u = usuarios.buscarEmail(email);

        if (u == null) {
            throw new UsuarioIncorrecto();
        }
        
        return u;
    }
    
    @RequestMapping(value = "/revisor/{email}/obtenerEstadoRevision", method = GET, produces = "application/json")
    public List<EstadoRevisionLibro> obtenerEstadoRevision(@PathVariable String email){
        if (email.equals("") || email == null) {
            throw new ParametrosIncorrectos();
        }
        
        List<EstadoRevisionLibro> librosPendRevision = sistema.obtenerEstadoRevision(email);
        return librosPendRevision;
    }
 
 
 
 
 
}

