/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.dae.servidor.RestController;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import org.springframework.web.bind.annotation.RestController;
import proyecto.dae.servidor.beans.Sistema;
import proyecto.dae.servidor.daos.AutorDAO;
import proyecto.dae.servidor.daos.RevisorDAO;
import proyecto.dae.servidor.daos.UsuarioDAO;
import proyecto.dae.servidor.servicios.dto.LibroDTO;

/**
 *
 * @author Loren
 */
@RestController
@RequestMapping("/libros")
public class LibrosRestController {
    @Autowired
    Sistema sistema;
    
    @RequestMapping(value="/descargaPorTitulo/{_titulo}",method=GET, produces="application/json")
    public LibroDTO descargarLibro(@PathVariable String _titulo){
           LibroDTO libroDTO=sistema.descargarLibro(_titulo);
           return libroDTO;
    }
    
    @RequestMapping(value="/consultaPorTematica/{_tematica}",method=GET, produces="application/json")
    public List<LibroDTO> consultaPorTematica(@PathVariable String _tematica){
           List<LibroDTO> libroDTO=sistema.consultarPorTematica(_tematica);
           return libroDTO;
    }
    
    @RequestMapping(value="/cargaBBDD",method=GET, produces="application/json")
    public void cargaBBDD(){
           sistema.cargaBBDD();
    }

    
//    @RequestMapping(value="/listaPendientesRevision", method=GET,produces="application/json")
//    public List<LibroDTO> verListaPendientesRevision(){
//           List<LibroDTO> librosPendientes=sistema.verListaPendientesRevisar(token);
//           return librosPendientes;
//    }
    
    
}
